
function Derivert = Derivasjon(Data, tidsskritt)
    Derivert = (Data(2)-Data(1))/tidsskritt;
end
